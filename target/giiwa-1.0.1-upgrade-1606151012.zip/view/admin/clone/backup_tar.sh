#!/bin/bash

cd $2
tar czf $1 *
