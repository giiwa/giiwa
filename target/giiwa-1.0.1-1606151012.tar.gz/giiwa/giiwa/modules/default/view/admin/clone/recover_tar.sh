#!/bin/bash

cd $2
tar xzf $1
